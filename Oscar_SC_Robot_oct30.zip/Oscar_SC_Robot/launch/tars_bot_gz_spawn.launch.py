from os.path import join
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.substitutions import LaunchConfiguration, Command
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory
from launch.launch_description_sources import PythonLaunchDescriptionSource

def generate_launch_description():
    tars_amr_path = get_package_share_directory("Oscar_SC_Robot")
    position_x = LaunchConfiguration("position_x")
    position_y = LaunchConfiguration("position_y")
    odometry_source = LaunchConfiguration("odometry_source")
    orientation_yaw = LaunchConfiguration("orientation_yaw")
    two_d_lidar_enabled = LaunchConfiguration("two_d_lidar_enabled", default=True)

    robot_state_publisher = Node(
        package="robot_state_publisher",
        executable="robot_state_publisher",
        name="robot_state_publisher",
        parameters=[{
            'robot_description': Command([
                'xacro ', join(tars_amr_path, 'description/new/oscar.urdf'),
                ' two_d_lidar_enabled:=', two_d_lidar_enabled,
                ' odometry_source:=', odometry_source,
                ' sim_gz:=', "true"
            ])
        }],
        remappings=[('/joint_states', '/joint_states')]
    )



    gz_spawn_entity = Node(
        package="ros_gz_sim",
        executable="create",
        arguments=[
            "-topic", "/robot_description",
            "-name", "my_bot",
            "-allow_renaming", "true",
            "-z", "0.28",
            "-x", position_x,
            "-y", position_y,
            "-Y", orientation_yaw

        ]
    )

    gz_ros2_bridge = Node(
        package="ros_gz_bridge",
        executable="parameter_bridge",
        arguments=[
            "/cmd_vel@geometry_msgs/msg/Twist@ignition.msgs.Twist",
            "/clock@rosgraph_msgs/msg/Clock[ignition.msgs.Clock",
            "/odom@nav_msgs/msg/Odometry[ignition.msgs.Odometry",
            "/scan@sensor_msgs/msg/LaserScan[ignition.msgs.LaserScan",
            "/tf@tf2_msgs/msg/TFMessage[ignition.msgs.Pose_V",
            "/world/default/model/my_bot/joint_state@sensor_msgs/msg/JointState[ignition.msgs.Model"
        ],
        remappings=[
            ('/world/default/model/my_bot/joint_state', '/joint_states'),
            ('/cmd_vel', '/cmd_vel'),
            ('/scan', '/scan'),
             ('/odom', '/odom'),
        ]
    )

    transform_publisher = Node(
        package="tf2_ros",
        executable="static_transform_publisher",
        arguments=[
            "--x", "0.0",
            "--y", "0.0",
            "--z", "0.0",
            "--yaw", "0.0",
            "--pitch", "0.0",
            "--roll", "0.0",
            "base_link", "world"  # Specify the parent and child frame IDs
        ]
    )

    return LaunchDescription([
        DeclareLaunchArgument("two_d_lidar_enabled", default_value=two_d_lidar_enabled),
        DeclareLaunchArgument("position_x", default_value="0.0"),
        DeclareLaunchArgument("position_y", default_value="0.0"),
        DeclareLaunchArgument("orientation_yaw", default_value="0.0"),
        DeclareLaunchArgument("odometry_source", default_value="world"),
        robot_state_publisher,
        gz_spawn_entity,
        transform_publisher,
        gz_ros2_bridge,
    ])